#!/usr/bin/env bash
set -euo pipefail
npm install
npm run type-check
npm run build

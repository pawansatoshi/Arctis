# ARCTIS GitHub Codespaces

1. Open the repository in GitHub Codespaces.
2. The container uses Node.js 22 and automatically runs `npm install`.
3. Start the app with `npm run dev`.
4. Open the forwarded port 3000.

Required environment variables are documented in `.env.example`. Never commit real wallet keys, Firebase secrets, or Circle credentials.

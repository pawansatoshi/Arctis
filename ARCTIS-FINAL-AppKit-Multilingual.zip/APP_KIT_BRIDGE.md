# ARCTIS Bridge — Circle App Kit

ARCTIS now uses Circle App Kit for USDC bridging on the browser wallet path.

## Execution architecture

`ARCTIS UI → EIP-1193 wallet provider → @circle-fin/adapter-viem-v2 → @circle-fin/app-kit → CCTP V2`

The application no longer performs its own `approve`, `depositForBurn`, Iris attestation polling, or destination mint orchestration in the bridge UI.

### Testnet source chains

- Ethereum Sepolia → Arc Testnet
- Base Sepolia → Arc Testnet
- Arbitrum Sepolia → Arc Testnet

The destination is Arc Testnet. App Kit handles the CCTP lifecycle after the source wallet approves the operation.

## Local development

Node.js 22+ is recommended.

```bash
npm install
npm run dev
```

The GitHub Codespaces configuration in `.devcontainer/devcontainer.json` installs dependencies automatically and forwards port 3000.

## Required environment

Copy `.env.example` to `.env.local` and fill the project-specific values required by the existing ARCTIS modules. Never commit private keys, Firebase service-account credentials, or other secrets.

## Important limitation

App Kit Bridge is for USDC bridging. ARCTIS-specific assets such as tUSDC and tARC remain outside the Circle bridge abstraction and continue to use ARCTIS application logic.

import { NextRequest, NextResponse } from 'next/server';
import { CCTP_SOURCE_CHAINS } from '@/lib/contracts';
import { BRIDGE_MIN_AMOUNT, BRIDGE_MAX_AMOUNT } from '@/lib/bridge/types';

/**
 * Lightweight pre-flight quote for the UI.
 * Actual bridge execution and protocol fee calculation are owned by Circle App Kit.
 * This endpoint intentionally does not call Iris or orchestrate CCTP.
 */
export async function GET(req: NextRequest) {
  const sourceChainParam = req.nextUrl.searchParams.get('sourceChain');
  const amountParam = req.nextUrl.searchParams.get('amount');

  if (!sourceChainParam || !amountParam) {
    return NextResponse.json({ error: 'sourceChain and amount required' }, { status: 400 });
  }

  const chain = CCTP_SOURCE_CHAINS[sourceChainParam as keyof typeof CCTP_SOURCE_CHAINS];
  if (!chain) return NextResponse.json({ error: 'Unsupported source chain' }, { status: 400 });

  const amount = Number(amountParam);
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: 'amount must be a positive number' }, { status: 400 });
  }
  if (amount < BRIDGE_MIN_AMOUNT || amount > BRIDGE_MAX_AMOUNT) {
    return NextResponse.json({ error: `Amount must be between ${BRIDGE_MIN_AMOUNT} and ${BRIDGE_MAX_AMOUNT} USDC` }, { status: 422 });
  }

  return NextResponse.json({
    sourceChain: chain.name,
    sourceChainId: Number(sourceChainParam),
    sourceDomain: chain.domain,
    destinationChain: 'Arc Testnet',
    destinationDomain: 26,
    fee: 0,
    feeToken: 'USDC',
    estimatedTime: '~30 seconds',
    minAmount: BRIDGE_MIN_AMOUNT,
    maxAmount: BRIDGE_MAX_AMOUNT,
    feeEstimated: true,
    note: 'Live bridge estimate is calculated by Circle App Kit in the connected wallet flow.',
  });
}

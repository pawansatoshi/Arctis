import { NextRequest, NextResponse } from 'next/server';
import { createPublicClient, http } from 'viem';
import { CCTP_SOURCE_CHAINS, CHAIN_ID, NETWORK_NAME, txUrl } from '@/lib/contracts';
import { createBridgePending, bridgeTxAlreadyProcessed } from '@/lib/bridge/service';
import { saveTransaction } from '@/lib/firebase/transactions';
import { writeActivity, buildBridgeActivity } from '@/lib/firebase/activity';
import { logTreasuryEvent } from '@/lib/treasury/service';
import { isValidEthAddress } from '@/lib/auth/middleware';
import { checkRateLimit, RATE_LIMITS } from '@/lib/security/rateLimit';
import { BRIDGE_MAX_AMOUNT, BRIDGE_MIN_AMOUNT } from '@/lib/bridge/types';

const SOURCE_RPC: Record<number, string> = {
  11155111: 'https://ethereum-sepolia-rpc.publicnode.com',
  84532: 'https://sepolia.base.org',
  421614: 'https://sepolia-rollup.arbitrum.io/rpc',
};

/**
 * Records a successful Circle App Kit bridge after independently checking
 * that the source transaction exists, succeeded, and was sent by the wallet.
 * This endpoint never executes CCTP and never accepts arbitrary wallet claims.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as {
      burnTxHash?: string; forwardTxHash?: string; sourceChainId?: number; walletAddress?: string; amount?: number;
    };
    const { burnTxHash, forwardTxHash, sourceChainId, walletAddress, amount } = body;

    if (!burnTxHash || !sourceChainId || !walletAddress || !amount) {
      return NextResponse.json({ error: 'burnTxHash, sourceChainId, walletAddress, amount required' }, { status: 400 });
    }
    if (!/^0x[0-9a-fA-F]{64}$/.test(burnTxHash) || (forwardTxHash && !/^0x[0-9a-fA-F]{64}$/.test(forwardTxHash))) {
      return NextResponse.json({ error: 'Invalid transaction hash format' }, { status: 400 });
    }
    if (!isValidEthAddress(walletAddress)) return NextResponse.json({ error: 'Invalid wallet address' }, { status: 400 });
    if (amount < BRIDGE_MIN_AMOUNT || amount > BRIDGE_MAX_AMOUNT) return NextResponse.json({ error: 'Bridge amount outside configured limits' }, { status: 422 });

    const chain = CCTP_SOURCE_CHAINS[String(sourceChainId) as keyof typeof CCTP_SOURCE_CHAINS];
    const rpc = SOURCE_RPC[sourceChainId];
    if (!chain || !rpc) return NextResponse.json({ error: 'Unsupported source chain' }, { status: 400 });

    const rl = await checkRateLimit(`bridge-record:${walletAddress.toLowerCase()}`, RATE_LIMITS.bridge.maxCalls, RATE_LIMITS.bridge.windowMs);
    if (!rl.allowed) return NextResponse.json({ error: 'Too many bridge record requests' }, { status: 429 });

    const existing = await bridgeTxAlreadyProcessed(burnTxHash);
    if (existing) return NextResponse.json({ bridge: existing, alreadyRecorded: true });

    const client = createPublicClient({ transport: http(rpc) });
    const tx = await client.getTransaction({ hash: burnTxHash as `0x${string}` });
    if (tx.from.toLowerCase() !== walletAddress.toLowerCase()) return NextResponse.json({ error: 'Source transaction does not belong to the supplied wallet' }, { status: 403 });
    const receipt = await client.getTransactionReceipt({ hash: burnTxHash as `0x${string}` });
    if (receipt.status !== 'success') return NextResponse.json({ error: 'Source bridge transaction did not succeed' }, { status: 422 });

    const now = new Date().toISOString();
    await createBridgePending({
      burnTxHash,
      walletAddress,
      sourceChain: chain.name,
      sourceChainId,
      sourceDomain: chain.domain,
      destinationChain: 'Arc Testnet',
      destinationDomain: 26,
      amount,
      status: 'completed',
      forwardTxHash,
    });

    await Promise.allSettled([
      saveTransaction(walletAddress, {
        toAddress: walletAddress,
        amount: String(amount),
        amountFormatted: String(amount),
        txHash: forwardTxHash ?? burnTxHash,
        status: 'confirmed',
        token: 'USDC',
        chainId: CHAIN_ID,
        networkName: NETWORK_NAME,
        explorerUrl: forwardTxHash ? txUrl(forwardTxHash) : `${chain.explorer}/tx/${burnTxHash}`,
        type: 'bridge',
        note: `Bridged from ${chain.name} via Circle App Kit / CCTP V2`,
      }),
      writeActivity(buildBridgeActivity(walletAddress, amount, chain.name, burnTxHash, forwardTxHash ?? burnTxHash)),
      logTreasuryEvent('bridge_inbound_activity', amount, `USDC bridged from ${chain.name} via Circle App Kit`, walletAddress, forwardTxHash ?? burnTxHash),
    ]);

    return NextResponse.json({
      bridgeId: burnTxHash,
      status: 'completed',
      burnTxHash,
      forwardTxHash: forwardTxHash ?? null,
      completedAt: now,
    });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unable to record bridge' }, { status: 500 });
  }
}

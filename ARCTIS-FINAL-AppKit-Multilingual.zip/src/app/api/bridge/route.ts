import { NextRequest, NextResponse } from 'next/server';
import { CCTP_SOURCE_CHAINS } from '@/lib/contracts';

const APP_KIT_CHAIN_BY_ID: Record<string, string> = {
  '11155111': 'Ethereum_Sepolia',
  '84532': 'Base_Sepolia',
  '421614': 'Arbitrum_Sepolia',
};

export async function GET(_req: NextRequest) {
  const routes = Object.entries(CCTP_SOURCE_CHAINS).map(([chainId, chain]) => ({
    sourceChain: chain.name,
    sourceChainId: Number(chainId),
    sourceDomain: chain.domain,
    usdc: chain.usdc,
    explorer: chain.explorer,
    enabled: Boolean(APP_KIT_CHAIN_BY_ID[chainId]),
    appKitChain: APP_KIT_CHAIN_BY_ID[chainId] ?? null,
  })).filter((route) => route.enabled);

  return NextResponse.json({
    available: true,
    mode: 'circle_app_kit',
    protocol: 'CCTP V2',
    direction: 'inbound_only',
    destination: {
      chain: 'Arc Testnet',
      chainId: 5042002,
      domain: 26,
    },
    routes,
  });
}

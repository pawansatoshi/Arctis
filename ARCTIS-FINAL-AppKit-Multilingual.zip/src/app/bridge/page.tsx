'use client';

import { useState, useEffect, useCallback, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { useAccount, useSwitchChain } from 'wagmi';
import { createViemAdapterFromProvider } from '@circle-fin/adapter-viem-v2';
import { AppKit } from '@circle-fin/app-kit';
import {
  GitMerge, CheckCircle2, AlertCircle, ExternalLink,
  ChevronDown, RefreshCw, History, Wallet, Info, Loader2, Clock,
} from 'lucide-react';
import { cn, formatRelative, formatAddress } from '@/lib/utils';
import { txUrl } from '@/lib/contracts';
import { buildBridgeMemo } from '@/lib/memo/service';
import { useMemo as useArcMemo } from '@/lib/memo/useMemo';
import { useAppStore } from '@/lib/store';
import { ModeTabs, type ExecutionMode } from '@/components/agent/ModeTabs';
import { EconomicAgentPanel } from '@/components/agent/EconomicAgentPanel';
import toast from 'react-hot-toast';

type AppKitChain = 'Ethereum_Sepolia' | 'Base_Sepolia' | 'Arbitrum_Sepolia';

interface BridgeRoute {
  sourceChain: string; sourceChainId: number; sourceDomain: number;
  usdc: string; explorer: string; enabled: boolean;
}
interface BridgeQuote {
  sourceChain: string; sourceChainId: number; sourceDomain: number;
  destinationChain: string; destinationDomain: number;
  fee: number; feeToken: string; estimatedTime: string;
  minAmount: number; maxAmount: number; feeEstimated?: boolean;
}
interface BridgeRecord {
  burnTxHash: string; walletAddress: string; sourceChain: string; sourceChainId: number;
  amount: number; status: string; forwardTxHash?: string; createdAt: string; completedAt?: string;
}
type BridgeStep = 'idle' | 'executing' | 'completed' | 'timeout' | 'error';

const APP_KIT_CHAIN_BY_ID: Record<number, AppKitChain> = {
  11155111: 'Ethereum_Sepolia',
  84532: 'Base_Sepolia',
  421614: 'Arbitrum_Sepolia',
};

const MIN_BRIDGE_AMOUNT = 0.000001;
const MAX_BRIDGE_AMOUNT = 1000;

function extractTxHashes(result: any): { burnTxHash?: string; forwardTxHash?: string } {
  const steps = Array.isArray(result?.steps) ? result.steps : [];
  const hashes = steps
    .map((step: any) => ({ name: String(step?.name ?? ''), hash: step?.txHash ?? step?.data?.txHash }))
    .filter((x: { hash?: string }) => typeof x.hash === 'string');
  const burn = hashes.find((x: { name: string }) => /burn|deposit/i.test(x.name))?.hash;
  const mint = hashes.find((x: { name: string }) => /mint|receive|forward/i.test(x.name))?.hash;
  return {
    burnTxHash: burn ?? hashes[0]?.hash,
    forwardTxHash: result?.forwardTxHash ?? mint ?? (hashes.length > 1 ? hashes[hashes.length - 1]?.hash : undefined),
  };
}

function BridgePageInner() {
  const searchParams = useSearchParams();
  const { isConnected, address, chainId, connector } = useAccount();
  const { switchChainAsync, isPending: isSwitching } = useSwitchChain();
  const { dispatchMemo } = useArcMemo();
  const { pendingAction, setPendingAction } = useAppStore();

  const [routes, setRoutes] = useState<BridgeRoute[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<BridgeRoute | null>(null);
  const [showChainMenu, setShowChainMenu] = useState(false);
  const [amount, setAmount] = useState('');
  const [quote, setQuote] = useState<BridgeQuote | null>(null);
  const [step, setStep] = useState<BridgeStep>('idle');
  const [burnTxHash, setBurnTxHash] = useState<string | undefined>();
  const [forwardTxHash, setForwardTxHash] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [history, setHistory] = useState<BridgeRecord[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [mode, setMode] = useState<ExecutionMode>('manual');
  const [agentExecuting, setAgentExecuting] = useState(false);

  useEffect(() => {
    if (searchParams.get('mode') === 'agent') setMode('agent');
  }, [searchParams]);

  useEffect(() => {
    fetch('/api/bridge').then((r) => r.json()).then((d) => {
      if (d.routes) {
        setRoutes(d.routes);
        setSelectedRoute((prev: BridgeRoute | null) => prev ?? d.routes[0] ?? null);
      }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!address) return;
    try {
      const stored = localStorage.getItem(`arctis-bridge-history:${address.toLowerCase()}`);
      if (stored) setHistory(JSON.parse(stored));
    } catch { /* local history is non-critical */ }
  }, [address]);

  useEffect(() => {
    if (!showHistory || !address) return;
    fetch(`/api/bridge/history?wallet=${address}`).then((r) => r.json())
      .then((d) => {
        if (d.bridges?.length) {
          setHistory((prev) => {
            const merged = [...d.bridges, ...prev];
            return Array.from(new Map(merged.map((b: BridgeRecord) => [b.burnTxHash, b])).values()).slice(0, 50);
          });
        }
      }).catch(() => {});
  }, [showHistory, address]);

  useEffect(() => {
    if (pendingAction?.action !== 'bridge') return;
    setAmount(pendingAction.amount);
    if (pendingAction.sourceChainId) {
      setSelectedRoute((prev) => routes.find((r) => r.sourceChainId === pendingAction.sourceChainId) ?? prev);
    }
    setPendingAction(null);
    toast.success('Pre-filled from ARCTIS AI — review before bridging');
  }, [pendingAction, routes, setPendingAction]);

  const amountNum = Number(amount);
  const amountValid = Number.isFinite(amountNum) && amountNum >= MIN_BRIDGE_AMOUNT && amountNum <= MAX_BRIDGE_AMOUNT;
  const onSourceChain = chainId === selectedRoute?.sourceChainId;
  const appKitChain = selectedRoute ? APP_KIT_CHAIN_BY_ID[selectedRoute.sourceChainId] : undefined;

  const loadEstimate = useCallback(async () => {
    if (!selectedRoute || !amountValid || !connector || !appKitChain) {
      setQuote(null);
      return;
    }
    try {
      if (chainId !== selectedRoute.sourceChainId) {
        setQuote({ sourceChain: selectedRoute.sourceChain, sourceChainId: selectedRoute.sourceChainId, sourceDomain: selectedRoute.sourceDomain, destinationChain: 'Arc Testnet', destinationDomain: 26, fee: 0, feeToken: 'USDC', estimatedTime: '~30 seconds', minAmount: MIN_BRIDGE_AMOUNT, maxAmount: MAX_BRIDGE_AMOUNT, feeEstimated: true });
        return;
      }
      const provider = await connector.getProvider();
      const adapter = await createViemAdapterFromProvider({ provider: provider as any });
      const kit = new AppKit();
      const estimate: any = await kit.estimateBridge({
        from: { adapter, chain: appKitChain },
        to: { adapter, chain: 'Arc_Testnet' },
        amount: amountNum.toFixed(6),
      });
      const fee = Number(estimate?.fees?.total ?? estimate?.fees?.protocol ?? estimate?.fee ?? 0);
      setQuote({
        sourceChain: selectedRoute.sourceChain, sourceChainId: selectedRoute.sourceChainId, sourceDomain: selectedRoute.sourceDomain,
        destinationChain: 'Arc Testnet', destinationDomain: 26,
        fee: Number.isFinite(fee) ? fee : 0, feeToken: 'USDC', estimatedTime: '~30 seconds',
        minAmount: MIN_BRIDGE_AMOUNT, maxAmount: MAX_BRIDGE_AMOUNT,
      });
    } catch {
      setQuote({
        sourceChain: selectedRoute.sourceChain, sourceChainId: selectedRoute.sourceChainId, sourceDomain: selectedRoute.sourceDomain,
        destinationChain: 'Arc Testnet', destinationDomain: 26,
        fee: 0, feeToken: 'USDC', estimatedTime: '~30 seconds', minAmount: MIN_BRIDGE_AMOUNT, maxAmount: MAX_BRIDGE_AMOUNT,
        feeEstimated: true,
      });
    }
  }, [selectedRoute, amountValid, connector, appKitChain, chainId, amountNum]);

  useEffect(() => {
    const timer = setTimeout(() => { void loadEstimate(); }, 350);
    return () => clearTimeout(timer);
  }, [loadEstimate]);

  const saveLocalHistory = useCallback((record: BridgeRecord) => {
    if (!address) return;
    setHistory((prev) => {
      const merged = [record, ...prev.filter((b) => b.burnTxHash !== record.burnTxHash)].slice(0, 50);
      try { localStorage.setItem(`arctis-bridge-history:${address.toLowerCase()}`, JSON.stringify(merged)); } catch { /* non-critical */ }
      return merged;
    });
  }, [address]);

  const executeBridge = useCallback(async (bridgeAmount: string, route: BridgeRoute) => {
    if (!isConnected || !address || !connector) throw new Error('Connect a compatible EVM wallet first');
    const sourceKitChain = APP_KIT_CHAIN_BY_ID[route.sourceChainId];
    if (!sourceKitChain) throw new Error('This source chain is not enabled in Circle App Kit');
    const parsed = Number(bridgeAmount);
    if (!Number.isFinite(parsed) || parsed < MIN_BRIDGE_AMOUNT || parsed > MAX_BRIDGE_AMOUNT) {
      throw new Error(`Amount must be between ${MIN_BRIDGE_AMOUNT} and ${MAX_BRIDGE_AMOUNT} USDC`);
    }

    setErrorMsg(null);
    setStep('executing');
    try {
      if (chainId !== route.sourceChainId) {
        await switchChainAsync({ chainId: route.sourceChainId });
      }
      const provider = await connector.getProvider();
      const adapter = await createViemAdapterFromProvider({ provider: provider as any });
      const kit = new AppKit();

      const result: any = await kit.bridge({
        from: { adapter, chain: sourceKitChain },
        to: { adapter, chain: 'Arc_Testnet' },
        amount: parsed.toFixed(6),
      });

      if (result?.state !== 'success') {
        const failed = Array.isArray(result?.steps) ? result.steps.filter((s: any) => s?.state === 'error') : [];
        throw new Error(failed[0]?.error?.message ?? 'Circle App Kit could not complete the bridge');
      }

      const hashes = extractTxHashes(result);
      setBurnTxHash(hashes.burnTxHash);
      setForwardTxHash(hashes.forwardTxHash ?? null);
      setStep('completed');

      if (hashes.burnTxHash) {
        void dispatchMemo(buildBridgeMemo(hashes.burnTxHash, route.sourceDomain, 26, route.sourceChain));
        void fetch('/api/bridge/record', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            burnTxHash: hashes.burnTxHash,
            forwardTxHash: hashes.forwardTxHash,
            sourceChainId: route.sourceChainId,
            walletAddress: address,
            amount: parsed,
          }),
        }).catch(() => {});
      }

      saveLocalHistory({
        burnTxHash: hashes.burnTxHash ?? `appkit-${Date.now()}`,
        walletAddress: address,
        sourceChain: route.sourceChain,
        sourceChainId: route.sourceChainId,
        amount: parsed,
        status: 'completed',
        forwardTxHash: hashes.forwardTxHash,
        createdAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      });
      toast.success(`${parsed} USDC arrived on Arc Testnet`);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Bridge failed';
      setErrorMsg(message);
      setStep('error');
      throw err;
    }
  }, [isConnected, address, connector, chainId, switchChainAsync, dispatchMemo, saveLocalHistory]);

  const executeAgentBridge = useCallback(async (proposal: import('@/lib/store').PendingFinancialAction) => {
    const route = routes.find((r) => r.sourceChainId === proposal.sourceChainId) ?? selectedRoute;
    if (!route) throw new Error('Choose a supported bridge source chain');
    if (!proposal.amount) throw new Error('Bridge proposal is incomplete');
    setAmount(proposal.amount);
    setSelectedRoute(route);
    setAgentExecuting(true);
    try {
      await executeBridge(proposal.amount, route);
    } finally {
      setAgentExecuting(false);
    }
  }, [routes, selectedRoute, executeBridge]);

  const handleManualBridge = async () => {
    if (!selectedRoute) return;
    try { await executeBridge(amount, selectedRoute); } catch { /* state already contains the error */ }
  };

  const handleSwitchToSource = async () => {
    if (!selectedRoute) return;
    try {
      if (chainId === selectedRoute.sourceChainId) { toast.success(`Already on ${selectedRoute.sourceChain}`); return; }
      await switchChainAsync({ chainId: selectedRoute.sourceChainId });
      toast.success(`Switched to ${selectedRoute.sourceChain}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Unable to switch network');
    }
  };

  const handleReset = () => {
    setStep('idle'); setAmount(''); setQuote(null); setBurnTxHash(undefined); setForwardTxHash(null); setErrorMsg(null); setAgentExecuting(false);
  };

  if (step === 'completed') {
    return (
      <div className="page-container max-w-lg flex items-center justify-center min-h-[60vh]">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="glass-card p-8 text-center space-y-6 w-full">
          <div className="w-16 h-16 rounded-full bg-emerald-500/15 flex items-center justify-center mx-auto"><CheckCircle2 className="w-8 h-8 text-emerald-600 dark:text-emerald-400" /></div>
          <div>
            <h2 className="text-xl font-bold text-surface-950 mb-1">Bridge Complete</h2>
            <p className="text-surface-600 text-sm">{amount} USDC arrived on Arc Testnet from {selectedRoute?.sourceChain}</p>
          </div>
          <div className="space-y-2">
            {burnTxHash && selectedRoute && <a href={`${selectedRoute.explorer}/tx/${burnTxHash}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between glass-card p-3 hover:bg-black/[0.06] dark:hover:bg-white/[0.06] transition-colors"><span className="text-surface-600 text-xs">Source tx ({selectedRoute.sourceChain})</span><span className="text-blue-600 dark:text-blue-400 text-xs flex items-center gap-1">View <ExternalLink className="w-3 h-3" /></span></a>}
            {forwardTxHash && <a href={txUrl(forwardTxHash)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between glass-card p-3 hover:bg-black/[0.06] dark:hover:bg-white/[0.06] transition-colors"><span className="text-surface-600 text-xs">Arc Testnet arrival</span><span className="text-blue-600 dark:text-blue-400 text-xs flex items-center gap-1">ArcScan <ExternalLink className="w-3 h-3" /></span></a>}
          </div>
          <div className="flex gap-2"><a href="/credits" className="btn-secondary flex-1 justify-center text-sm">Buy Credits</a><a href="/swap" className="btn-secondary flex-1 justify-center text-sm">Swap Tokens</a></div>
          <button onClick={handleReset} className="btn-ghost w-full justify-center"><RefreshCw className="w-4 h-4" /> New Bridge</button>
        </motion.div>
      </div>
    );
  }

  const canBridge = amountValid && !!selectedRoute && !!quote && isConnected && onSourceChain && step === 'idle';

  return (
    <div className="page-container max-w-lg safe-bottom">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }} className="flex items-center justify-between mb-8">
        <div><div className="flex items-center gap-2 mb-1"><span className="text-surface-500 text-xs font-semibold uppercase tracking-widest">Stablecoin OS</span></div><h1 className="text-2xl font-bold text-surface-950 tracking-tight">Bridge</h1><p className="text-surface-600 text-sm mt-1">Circle App Kit · CCTP V2 · Bring USDC to Arc Testnet</p></div>
        <button onClick={() => setShowHistory((s) => !s)} aria-label="Bridge history" className={cn('btn-ghost', showHistory && 'bg-blue-500/10 text-blue-600 dark:text-blue-400')}><History className="w-4 h-4" /></button>
      </motion.div>

      <div className="mb-6"><ModeTabs mode={mode} onChange={setMode} /></div>

      {mode === 'agent' && <EconomicAgentPanel action="bridge" onExecute={executeAgentBridge} executionStatus={agentExecuting ? (step === 'error' ? 'failed' : step === 'completed' ? 'success' : 'executing') : 'idle'} executionError={step === 'error' ? errorMsg : null} executionTxHash={forwardTxHash ?? burnTxHash ?? null} />}

      {mode === 'manual' && (!isConnected ? (
        <div className="glass-card p-8 text-center"><Wallet className="w-8 h-8 text-surface-600 mx-auto mb-3" /><p className="text-surface-700">Connect your wallet to bridge USDC</p></div>
      ) : showHistory ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3"><p className="text-surface-600 text-xs font-medium uppercase tracking-wider">Bridge History</p>{history.length === 0 ? <div className="glass-card p-10 text-center"><GitMerge className="w-8 h-8 text-surface-500 mx-auto mb-3 opacity-50" /><p className="text-surface-600 text-sm">No bridges yet</p></div> : history.map((b) => <div key={`${b.burnTxHash}-${b.createdAt}`} className="glass-card p-4 flex items-center justify-between"><div><p className="text-surface-950 text-sm font-medium">{b.amount} USDC from {b.sourceChain}</p><p className="text-surface-500 text-xs">{formatRelative(b.createdAt)}</p></div><span className={cn('text-xs px-2 py-0.5 rounded-full', b.status === 'completed' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : b.status === 'failed' ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' : 'bg-blue-500/10 text-blue-600 dark:text-blue-400')}>{b.status}</span></div>)}</motion.div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="glass-card p-5 space-y-3">
            <label className="text-surface-600 text-xs font-medium uppercase tracking-wider">From</label>
            <div className="relative">
              <button onClick={() => setShowChainMenu((s) => !s)} disabled={step !== 'idle'} className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-black/[0.04] dark:bg-white/[0.04] hover:bg-black/[0.07] dark:hover:bg-white/[0.07] border border-black/[0.08] dark:border-white/[0.08] transition-colors disabled:opacity-60"><span className="text-sm font-medium text-surface-950">{selectedRoute?.sourceChain ?? 'Select chain'}</span><ChevronDown className={cn('w-4 h-4 text-surface-600 transition-transform', showChainMenu && 'rotate-180')} /></button>
              <AnimatePresence>{showChainMenu && <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="absolute top-full left-0 right-0 mt-1 glass-card z-20 overflow-hidden">{routes.map((r) => <button key={r.sourceChainId} onClick={() => { setSelectedRoute(r); setShowChainMenu(false); setAmount(''); setQuote(null); setStep('idle'); setErrorMsg(null); }} className={cn('w-full px-4 py-3 text-left hover:bg-black/[0.06] dark:hover:bg-white/[0.06] transition-colors text-sm text-surface-950', r.sourceChainId === selectedRoute?.sourceChainId && 'bg-blue-500/10')}>{r.sourceChain}</button>)}</motion.div>}</AnimatePresence>
            </div>
            {selectedRoute && !onSourceChain && step === 'idle' && <button onClick={handleSwitchToSource} disabled={isSwitching} className="btn-secondary w-full justify-center text-sm">{isSwitching ? <Loader2 className="w-4 h-4 animate-spin" /> : `Switch to ${selectedRoute.sourceChain}`}</button>}
          </div>

          <div className="glass-card p-5 space-y-2.5"><label className="text-surface-600 text-xs font-medium uppercase tracking-wider">Amount (USDC)</label><input type="number" value={amount} placeholder="0.00" onChange={(e) => setAmount(e.target.value)} disabled={step !== 'idle'} className="input-field" min="0" step="0.000001" />{amount && !amountValid && <p className="text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5"><AlertCircle className="w-3 h-3" /> Amount must be between {MIN_BRIDGE_AMOUNT} and {MAX_BRIDGE_AMOUNT} USDC</p>}</div>

          <div className="glass-card p-4 flex items-center justify-between"><span className="text-surface-600 text-xs uppercase tracking-wider">To</span><span className="text-surface-950 text-sm font-medium">Arc Testnet {address && `(${formatAddress(address)})`}</span></div>

          {quote && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card p-4 space-y-2 text-sm"><div className="flex justify-between"><span className="text-surface-600">Fee</span><span className="text-surface-950 font-mono">{quote.fee.toFixed(4)} USDC</span></div><div className="flex justify-between"><span className="text-surface-600">Estimated time</span><span className="text-surface-950">{quote.estimatedTime}</span></div>{quote.feeEstimated && <p className="text-amber-600 dark:text-amber-400 text-xs flex items-center gap-1.5 pt-1"><Info className="w-3 h-3" /> Estimated fee — live estimate unavailable until source wallet is on the selected chain</p>}</motion.div>}

          {step === 'executing' && <div className="glass-card p-5 text-center space-y-3 border-blue-500/20 bg-blue-500/5"><Loader2 className="w-6 h-6 text-blue-600 dark:text-blue-400 animate-spin mx-auto" /><p className="text-surface-950 text-sm font-medium">Circle App Kit is executing the bridge…</p><p className="text-surface-600 text-xs">Approve and burn are handled by the SDK. Attestation and destination mint are orchestrated by Circle.</p></div>}
          {step === 'error' && errorMsg && <div className="glass-card p-3 border-rose-500/20 bg-rose-500/5 flex items-start gap-2"><AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 flex-shrink-0 mt-0.5" /><p className="text-rose-600 dark:text-rose-400 text-sm">{errorMsg}</p></div>}

          {(step === 'idle' || step === 'error') && (!onSourceChain && selectedRoute ? <button disabled className="btn-primary w-full justify-center opacity-40 cursor-not-allowed">Switch network to continue</button> : <button onClick={() => void handleManualBridge()} disabled={!canBridge} className="btn-primary w-full justify-center text-base py-3.5 disabled:opacity-40 disabled:cursor-not-allowed"><GitMerge className="w-4 h-4" /> Bridge USDC to Arc</button>)}
          {step === 'executing' && <button disabled className="btn-primary w-full justify-center opacity-70"><Loader2 className="w-4 h-4 animate-spin" /> Bridging…</button>}
          {step === 'error' && <button onClick={handleReset} className="btn-ghost w-full justify-center"><RefreshCw className="w-4 h-4" /> Try Again</button>}
          <p className="text-center text-surface-500 text-xs">Circle App Kit · CCTP V2 · Testnet only · Inbound to Arc</p>
        </motion.div>
      ))}
    </div>
  );
}

export default function BridgePage() {
  return <Suspense fallback={<div className="page-container max-w-lg flex items-center justify-center min-h-[60vh]"><div className="text-surface-500 text-sm">Loading…</div></div>}><BridgePageInner /></Suspense>;
}
